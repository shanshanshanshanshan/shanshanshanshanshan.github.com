;(function(window) {

var svgSprite = '<svg>' +
  ''+
    '<symbol id="icon-back" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M363.840919 472.978737C336.938714 497.358861 337.301807 537.486138 364.730379 561.486138L673.951902 832.05497C682.818816 839.813519 696.296418 838.915012 704.05497 830.048098 711.813519 821.181184 710.915012 807.703582 702.048098 799.94503L392.826577 529.376198C384.59578 522.174253 384.502227 511.835287 392.492414 504.59418L702.325747 223.807723C711.056111 215.895829 711.719614 202.404616 703.807723 193.674252 695.895829 184.943889 682.404617 184.280386 673.674253 192.192278L363.840919 472.978737Z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
    '<symbol id="icon-more" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M642.174253 504.59418C650.164439 511.835287 650.070886 522.174253 641.84009 529.376198L332.618569 799.94503C323.751654 807.703582 322.853148 821.181184 330.611697 830.048098 338.370249 838.915012 351.847851 839.813519 360.714765 832.05497L669.936288 561.486138C697.36486 537.486138 697.727953 497.358861 670.825747 472.978737L360.992414 192.192278C352.26205 184.280386 338.770837 184.943889 330.858944 193.674252 322.947053 202.404616 323.610556 215.895829 332.340919 223.807723L642.174253 504.59418Z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
    '<symbol id="icon-zanting" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M512.01598 0C229.68971 0 0 229.68971 0 512.01598s229.68971 511.98402 512.01598 511.98402c282.29431 0 511.98402-229.68971 511.98402-511.98402S794.31029 0 512.01598 0zM512.01598 960.081895C264.940545 960.081895 63.918105 759.059455 63.918105 512.01598S264.940545 63.918105 512.01598 63.918105c247.043476 0 448.065916 201.02244 448.065916 448.097875S759.059455 960.081895 512.01598 960.081895z"  ></path>'+
      ''+
      '<path d="M743.079929 472.195l-279.833463-171.172685-4.122718-2.141257c-2.36497-1.02269-23.969289-9.939265-46.947848-9.939265-39.757061 0-65.484098 26.430136-65.484098 67.273805l0 324.895727 1.725789 5.017571c6.008302 17.673356 26.174464 47.55507 63.374801 47.55507l0 0c11.824849 0 24.065167-3.195905 37.551887-10.099061l276.637558-156.791111 2.716519-1.757748c19.047595-13.48672 39.629225-47.363316 18.440373-85.522424L743.079929 472.195zM419.047096 667.368934c-4.026841 2.045379-6.295933 2.36497-7.030992 2.428888-0.383509-0.319591-0.862894-0.862894-1.374239-1.534035l0-312.048188c0-1.374239 0.063918-2.492806 0.191754-3.323741 5.912425-0.319591 16.970257 2.460847 21.508442 4.122718l256.918823 157.142661L419.047096 667.368934z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
    '<symbol id="icon-iconfontzanting" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M335.936 909.411c0 60.469-49.021 109.491-109.491 109.491l0 0c-60.47 0-109.491-49.022-109.491-109.491L116.954 114.589c0-60.47 49.021-109.491 109.491-109.491l0 0c60.47 0 109.491 49.021 109.491 109.491L335.936 909.411zM907.046 909.411c0 60.469-49.022 109.491-109.491 109.491l0 0c-60.469 0-109.491-49.022-109.491-109.491L688.064 114.589c0-60.47 49.022-109.491 109.491-109.491l0 0c60.469 0 109.491 49.021 109.491 109.491L907.046 909.411z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
'</svg>'
var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
var shouldInjectCss = script.getAttribute("data-injectcss")

/**
 * document ready
 */
var ready = function(fn){
  if(document.addEventListener){
      document.addEventListener("DOMContentLoaded",function(){
          document.removeEventListener("DOMContentLoaded",arguments.callee,false)
          fn()
      },false)
  }else if(document.attachEvent){
     IEContentLoaded (window, fn)
  }

  function IEContentLoaded (w, fn) {
      var d = w.document, done = false,
      // only fire once
      init = function () {
          if (!done) {
              done = true
              fn()
          }
      }
      // polling for no errors
      ;(function () {
          try {
              // throws errors until after ondocumentready
              d.documentElement.doScroll('left')
          } catch (e) {
              setTimeout(arguments.callee, 50)
              return
          }
          // no errors, fire

          init()
      })()
      // trying to always fire before onload
      d.onreadystatechange = function() {
          if (d.readyState == 'complete') {
              d.onreadystatechange = null
              init()
          }
      }
  }
}

/**
 * Insert el before target
 *
 * @param {Element} el
 * @param {Element} target
 */

var before = function (el, target) {
  target.parentNode.insertBefore(el, target)
}

/**
 * Prepend el to target
 *
 * @param {Element} el
 * @param {Element} target
 */

var prepend = function (el, target) {
  if (target.firstChild) {
    before(el, target.firstChild)
  } else {
    target.appendChild(el)
  }
}

function appendSvg(){
  var div,svg

  div = document.createElement('div')
  div.innerHTML = svgSprite
  svg = div.getElementsByTagName('svg')[0]
  if (svg) {
    svg.setAttribute('aria-hidden', 'true')
    svg.style.position = 'absolute'
    svg.style.width = 0
    svg.style.height = 0
    svg.style.overflow = 'hidden'
    prepend(svg,document.body)
  }
}

if(shouldInjectCss && !window.__iconfont__svg__cssinject__){
  window.__iconfont__svg__cssinject__ = true
  try{
    document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
  }catch(e){
    console && console.log(e)
  }
}

ready(appendSvg)


})(window)
